<!DOCTYPE html>
<html lang="en">
    <head>
        @include('partials.head')
    </head>
    <body class="@yield('body_class', 'd-flex flex-column h-100')">
        <main class="flex-shrink-0">
            @include('partials.nav')

            @yield('content')
        </main>

        @include('partials.footer')

        @include('partials.scripts')
        @stack('scripts')
    </body>
</html>

